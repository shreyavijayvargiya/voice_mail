n=-30:30;
x1 = cos(2*pi*0.1*n);
subplot(3,1,1);
stem(n,x1);
xlabel('time sample');
ylabel('Amplitude');
title('1st input signal');
x2=cos(2*pi*0.4*n);
subplot(3,1,2);
stem(n,x2);
xlabel('time sample');
ylabel('Amplitude');
title('2nd input signal');
num=[2.2403 2.4908 2.2403];
den=[1 -0.4 0.75];
a=2;
b=-3;
y1=filter(num,den,x1);
y2=filter(num,den,x2);
x3=a*x1+b*x2;
y3=filter(num,den,x3);
z=a*y1+b*y2;
p=y3-z;
subplot(3,1,3);

stem(n,p);
title("signal after processing");

if (p<power(10,-3)) %checks both sides difference is almost equal
    disp('Linear System')
else
    disp('Non linear system');
end