clc
clear all
close all
num=[2.2403 2.4908 2.2403];
den=[1 -0.4 0.75];
y=impz(num,den);
subplot(2,1,1);
plot(y);
subplot(2,1,2);
stem(y);