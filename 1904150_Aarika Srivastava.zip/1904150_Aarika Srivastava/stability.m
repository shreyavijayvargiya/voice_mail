%system eqn y(n)= 0.9y(n-1)*x(n)
%stability 
clc;
close all;

num=[2.2403 2.4908 2.2403];
den=[1 -0.4 0.75];
y=impz(num,den);
subplot(2,1,1);
plot(y);
subplot(2,1,2);
stem(y);
a=roots(den);
if(abs(a)<1)
    disp('stable system');
else
    disp('unstable system');
    
end